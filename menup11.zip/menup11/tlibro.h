#ifndef TLIBRO_LIBRARY_H
#define TLIBRO_LIBRARY_H

struct tlibro{
    char ISBN[10];
    int anoPubli;
    char titulo[10];
};

void crear0(tlibro &l);
//Pre: -
//Pos: crea un nuebo libro con los datos introducidos por pantalla.

void crearDatosDados(tlibro &l, char I[], int a, char t[]);
//Pre: enteros validos en los campos y char max 10 caracteres.
//Pos: crea nuevo libro con los datos dados.

void modiAno(tlibro &l, int cambio);
//Pre:
//Pos: modifica el ano de publicacion del libro y lo cambia por elo introducido por pantalla.



int obAno(tlibro l);
//Pre:
//Pos: devuelve el año de publicacion del libro.

void mostrarLibro(tlibro l);




#endif //TLIBRO_LIBRARY_H
