#include "tlibro.h"
using namespace std;
#include <iostream>
#include "string.h"

void crear0(tlibro &l, char I[]){
    cout<<"Introduce su ISBN"<<endl;
    strcpy(l.ISBN, I);
    cout<<endl;
    cout<<"Introduce su titulo"<<endl;
    cin.getline(l.titulo, 10, '\n');
    cout<<endl;
    cout<<"Introduce su ano de publicacion"<<endl;
    cin>>l.anoPubli;
}
void modiAno(tlibro &l, int cambio){
    l.anoPubli=cambio;
}
int obAno(tlibro l){
    return l.anoPubli;
}
void crearDatosDados(tlibro &l, char I[], int a, char t[]) {
    l.anoPubli=a;
    strcpy(l.ISBN, I);
    strcpy(l.titulo, t);
}
void mostrarLibro(tlibro l){
    cout<<"ISBN: "<<l.ISBN<<endl;
    cout<<"Titulo: "<<l.titulo<<endl;
    cout<<"Ano publicacion: "<<l.anoPubli<<endl;
}

