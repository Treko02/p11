#ifndef BIBLIOGRAFIA_BIBLIOGAFIA_H
#define BIBLIOGRAFIA_BIBLIOGAFIA_H

#include "tlibro.h"

typedef tlibro tlibro;

struct tbibliografia{
    tlibro l;
    tbibliografia * sig;
};

void iniciar(tbibliografia &b);
/*
{Pre: }
{Post: Inicia b como una bibliografía sin libros.}
 */
void anadir(tbibliografia &b);
    /*
    {Pre: b es una bibliografía iniciada}
    {Post: Añade el libro l a la bibliografía b.}
     */
    void eliminar(tbibliografia &b, char ISBN[]);
    /*
    {Pre: ISBN es un ISBN de los libros de la bibliografía b}
    {Post: Elimina el libro cuyo ISBN es ISBN de la bibliografía b.}
     */
    void extraerISBN(tbibliografia b, char ISBN[], tlibro & l);
    /*
    {Pre: ISBN es un ISBN de los libros de la bibliografía b}
    {Post: Devuelve de la bibliografía b los datos del libro cuyo ISBN es ISBN.}
    */
     void extraerPosicion(tbibliografia b, int pos, tlibro & l);
    /*
     {Pre: pos es un entero menor que el número de libros de la bibliografía b, b es una bibliografía iniciada}
    {Post: Devuelve de la bibliografía b los datos del libro que ocupa la posición pos, empezando a contar en 0, en la bibliografía.}
    */
     bool bibliografiaSinLibros (tbibliografia b);
    /*
     {Pre: b es una bibliografía iniciada}
    {Post: Devuelve true si la bibliografía no tiene libros y false en caso contrario.}
     */
    int numeroLibros (tbibliografia b);
    /*
    {Pre: b es una bibliografía iniciada}
    {Post: Devuelve el número de libros de la bibliografía b.}
     */
    void copiarBibliografia(tbibliografia b, tbibliografia &b1);
    /*
    {Pre: b es una bibliografía ya iniciada}
    {Post: b1 es una copia de b, b no se modifica}
     */
    void mostrarBibliografia(tbibliografia b);
    /*
    {Pre: b es una bibliografía ya iniciada}
    {Post: muestra los libros almacenados en la bibliografía b, b no se modifica}
    */
    bool existe (tbibliografia b, char ISBN[]);
    /*
    {Pre: b es una bibliografía iniciada}
    {Post: Devuelve true si en la bibliografía b hay un libro cuyo ISBN es ISBN, y devuelve false en caso contrario.}
    */
     void modificarAnioLibro(tbibliografia &b, char ISBN[], float anio);
    /*
     {Pre: ISBN es un ISBN de los libros de la bibliografía b}
    {Post: Modifica el año de publicación del libro de la bibliografía b cuyo ISBN es ISBN poniendo como nuevo año de publicación anio.}
    */
     void masNuevo(tbibliografia b, tlibro & l);
     /*
    {Pre: la bibliografía b no debe estar vacía}
    {Post: l es el libro cuyo año de publicación es el mayor de la bibliografía b. En caso de haber varios libros con el mismo año de publicación, solo devuelve uno.}
    */
#endif //BIBLIOGRAFIA_BIBLIOGAFIA_H
