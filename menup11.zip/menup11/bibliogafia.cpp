#include "bibliogafia.h"
#include "tlibro.h"
#include <iostream>
using namespace std;

void iniciar(tbibliografia &b) {
    b.sig=NULL;
}
void anadir(tbibliografia &b){
    tbibliografia *p, *nuevo;
    nuevo=new (tbibliografia);
    crear0((*nuevo).l, );
    if (b.sig==NULL){
        b.sig=nuevo;
    }else{
        p=b.sig;
        while (p->sig!=NULL){
            p=p->sig;
        }
        p->sig=nuevo;

    }

}
void mostrarBibliografia(tbibliografia b){
    tbibliografia * aux;
    aux=b.sig;
    while (aux!=NULL){
        mostrarLibro(aux->l);
        aux=aux->sig;
    }

}
