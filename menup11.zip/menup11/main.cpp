#include <iostream>
#include "bibliogafia.h"
#include "tlibro.h"
using namespace std;

int main() {
    tbibliografia b;
    int o;
    do{
        cout<<"1.- Crear bibliografía"<<endl;
        cout<<"2.- Añadir libro"<<endl;
        cout<<"3.- Modificar año de libro"<<endl;
        cout<<"4.- Listar libros por ISBN"<<endl;
        cout<<"5.- Listar libros por orden decreciente de año"<<endl;
        cout<<"6.- Buscar libro por ISBN"<<endl;
        cout<<"7.- Eliminar libro por ISBN"<<endl;
        cout<<"8.- Indicar el número de libros que existen"<<endl;
        cout<<"9.- Copiar una bibliografía"<<endl;
        cout<<"10.- Terminar"<<endl;
        cin>>o;
        switch(o){
            case 1:
                iniciar(b);
                break;
            case 2:
                anadir(b);
                mostrarBibliografia(b);
        }
    }while (o!=10);
    return 0;
}
